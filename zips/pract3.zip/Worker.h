#ifndef WORKER_H
#define WORKER_H

#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

class Worker
{
public:
    Worker(string name, double salary);
    ~Worker();
    Worker &operator=(string name);
    Worker &operator=(double salary);
    Worker &operator+=(int increase);
    Worker &operator-=(int decrease);
    bool operator==(const Worker &other) const;
    bool operator!=(const Worker &other) const;
    bool operator>(const Worker &other) const;
    bool operator<(const Worker &other) const;
    bool operator>=(const Worker &other) const;
    bool operator<=(const Worker &other) const;
    Worker &operator=(const Worker &other);
    double operator()() const;
    friend ostream &operator<<(ostream &os, const Worker &worker);
    double getSalary() const
    {
        return salary;
    }
    std::string getName() const
    {
        return name;
    }
    void setId(int id)
    {
        ID = id;
    }

private:
    static int idCounter;
    int ID;
    string name;
    double salary;
};

#endif
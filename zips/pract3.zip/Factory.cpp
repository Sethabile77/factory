#include "Factory.h"
using namespace std;

Factory::Factory()
{
    numWorkers = 0;
    workers = NULL;

    workers = new Worker *[0];
}
Factory::~Factory()
{
    if (workers != NULL)
    {
        delete[] *workers;
        delete workers;
        workers = NULL;
    }
}

Factory &Factory::operator=(const Factory &other)
{
    if (this == &other)
    {
        return *this;
    }
    delete[] workers;
    workers = new Worker *[numWorkers];
    for (int i = 0; i < numWorkers; i++)
    {
        this->workers[i] = other.workers[i];
    }
    return *this;
}

Factory &Factory::operator|(string filename)
{
    std::ifstream inputfile(filename.c_str());
    if (!inputfile.is_open())
    {
        std::cout << "File doesn't exist. " << std ::endl;
        return *this;
    }
    std::string input;

    while (getline(inputfile, input))
    {
        std::stringstream ss(input);
        std::string name;
        double salary;
        int ID;
        if (ss >> ID >> name >> salary)
        {
            Worker *file = new Worker(name, salary);
            *this += file;
        }
    }
    return *this;
}

int Factory::operator[](const Worker &worker) const
{

    if (this->workers == NULL || this->numWorkers == 0)
    {
        return -1;
    }
    for (int i = 0; i < this->numWorkers; i++)
    {
        if (*workers[i] == worker)
        {
            return i;
        }
    }
    return -1;
}
Worker *Factory::operator[](int index) const
{
    if (index < 0 || index >= numWorkers)
    {
        return NULL;
    }
    return workers[index];
}

void Factory::operator*=(const Factory &other)
{

    for (int i = 0; i < other.numWorkers; i++)
    {
        Worker *file = new Worker(*other.workers[i]);

        // Worker *file = new Worker(other.workers[i]->getName(), other.workers[i]->getSalary());
        ++numWorkers;

        this->workers[numWorkers] = file;
    }
}

Factory *Factory::operator*(const Factory &other) const
{
    Factory *fact = new Factory();
    for (int i = 0; i < this->numWorkers; i++)
    {
        Worker *file = new Worker(*this->workers[i]);
        *fact += file;
    }

    for (int i = 0; i < other.numWorkers; i++)
    {
        Worker *file = new Worker(*other.workers[i]);
        *fact += file;
    }
    return fact;
}

Factory &Factory::operator+=(Worker *worker)
{
    if (worker == NULL)
    {
        return *this;
    }
    for (int i = 0; i < numWorkers; i++)
    {

        if (workers[i]->getName() != worker->getName() && workers[i]->getSalary() != worker->getSalary())
        {
            Worker *file = new Worker(worker->getName(), worker->getSalary());

            ++numWorkers;
            file->setId(numWorkers);
            workers[numWorkers] = file;
        }
    }
    return *this;
}

Factory &Factory::operator+=(Worker &worker)
{
    ++numWorkers;
    workers[numWorkers] = &worker;
    return *this;
}
Factory &Factory::operator-=(Worker *worker)
{
    if (worker != NULL)
    {
        int index = -1;
        for (int i = 0; i < numWorkers; i++)
        {
            if (this->workers[i] == worker)
            {
                index = i;
                break;
            }
        }
        if (index != -1)
        {
            delete workers[index];
            for (int j = index; j < numWorkers; j++)
            {
                workers[j] = workers[j + 1];
            }

            --numWorkers;
            workers[numWorkers] = NULL;
        }
    }
    return *this;
}
bool Factory::operator==(const Factory &other) const
{

    if (this->totalSalary() == other.totalSalary())
    {
        return true;
    }
    return false;
}

bool Factory::operator!=(const Factory &other) const
{
    return this->totalSalary() != other.totalSalary();
}
const Factory &Factory::operator>(const Factory &other) const
{
    if (this->totalSalary() == other.totalSalary())
    {
        return *this;
    }
    if (this->totalSalary() > other.totalSalary())
    {
        return *this;
    }
    return *this;
}
const Factory &Factory::operator<(const Factory &other) const
{
    if (this->totalSalary() == other.totalSalary())
    {
        return *this;
    }
    if (this->totalSalary() < other.totalSalary())
    {
        return *this;
    }
    return *this;
}
const Factory &Factory::operator>=(const Factory &other) const
{

    if (this->totalSalary() >= other.totalSalary())
    {
        return *this;
    }
    return *this;
}
const Factory &Factory::operator<=(const Factory &other) const
{
    if (this->totalSalary() <= other.totalSalary())
    {
        return *this;
    }
    return *this;
}
ostream &operator<<(ostream &os, const Factory &factory)
{
    if (factory.workers == NULL)
    {
        os << "Empty factory";
    }
    for (int i = 0; i < factory.numWorkers; i++)
    {
        os << "Worker: " << *(factory.workers[i]) << '\n';
    }
    return os;
}
istream &operator>>(istream &is, const Factory &factory)
{
    std::string name;
    double salary;
    int ID;

    while (is >> ID >> name >> salary)
    {
        Worker(name, salary);
    }
    return is;
}
#include "Worker.h"

int Worker::idCounter = 1;

double Worker::getSalary() const
{
    return salary;
}
std::string Worker::getName() const
{
    return name;
}
void Worker::setId(int id)
{
    ID = id;
}
Worker::Worker(std::string name, double salary)
{
    this->name = name;
    this->salary = salary;
    ID = idCounter;
    idCounter++;
}

Worker::~Worker()
{
}
Worker &Worker::operator=(std::string name)
{
    if (name == "")
    {
        return *this;
    }
    this->name = name;
    return *this;
}
Worker &Worker::operator=(double salary)
{

    if (salary < 0)
    {
        return *this;
    }
    this->salary = salary;
    return *this;
}
Worker &Worker::operator+=(int increase)
{
    if (salary < 0)
    {
        return *this;
    }
    salary = salary + increase;
    return *this;
}
Worker &Worker::operator-=(int decrease)
{
    if (salary < 0)
    {
        return *this;
    }
    salary = salary - decrease;
    return *this;
}

bool Worker::operator==(const Worker &other) const
{
    if (this->name == other.name && this->salary == other.salary)
    {
        return true;
    }
    return false;
}

bool Worker::operator!=(const Worker &other) const
{
    if (this->name != other.name && this->salary != other.salary)
    {
        return true;
    }
    return false;
}

bool Worker::operator>(const Worker &other) const
{
    if (this->salary > other.salary)
    {
        return true;
    }
    return false;
}

bool Worker::operator<(const Worker &other) const
{
    if (this->salary < other.salary)
    {
        return true;
    }
    return false;
}
bool Worker::operator>=(const Worker &other) const
{
    if (this->salary >= other.salary)
    {
        return true;
    }
    return false;
}
bool Worker::operator<=(const Worker &other) const
{
    if (this->salary <= other.salary)
    {
        return true;
    }
    return false;
}
Worker &Worker::operator=(const Worker &other)
{
    if (this == &other)
    {
        return *this;
    }

    this->name = other.name;
    this->salary = other.salary;
    return *this;
}
double Worker::operator()() const
{
    return salary;
}
ostream &operator<<(ostream &os, const Worker &worker)
{
    os << "Worker: " << worker.ID << "," << worker.name << ",R" << std::setprecision(2) << worker.salary;
    return os;
}

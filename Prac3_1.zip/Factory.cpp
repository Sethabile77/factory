#include "Factory.h"
#include "Worker.h"
using namespace std;

Factory::Factory()
{
    numWorkers = 0;
    workers = new Worker *[0];
}
Factory &Factory::operator=(const Factory &other)
{
    if (this == &other)
    {
        return *this;
    }

    if (workers != NULL)
    {
        for (int i = 0; i < numWorkers; i++)
        {
            delete workers[i];
        }
        delete[] workers;
    }
    workers = NULL;
    numWorkers = other.numWorkers;

    if (numWorkers > 0)
    {
        workers = new Worker *[numWorkers];

        for (int i = 0; i < numWorkers; i++)
        {

            workers[i] = other.workers[i];
        }
    }

    else
    {
        workers = new Worker *[0];
    }

    return *this;
}
Factory::~Factory()
{

    if (workers != NULL)
    {

        for (int i = 0; i < numWorkers; i++)
        {
            delete workers[i];
        }

        delete[] workers;
        workers = NULL;
    }
    numWorkers = 0;
}

istream &operator>>(istream &is, Factory &factory)
{

    string input;
    while (std::getline(is, input))
    {
        if (input == "Empty factory" && input.empty() && input[input.size() - 1] == '\r')
        {
            continue;
        }

        const string prefix = "Worker: ";
        if (input.compare(0, prefix.size(), prefix) == 0)
        {
            input = input.substr(prefix.size());
        }
        std::stringstream ss(input);
        std::string id;
        std::string name;
        std::string salaryField;
        if (!std::getline(ss, id, ','))
        {
            continue;
        }
        if (!std::getline(ss, name, ','))
        {
            continue;
        }
        if (!std::getline(ss, salaryField))
        {
            continue;
        }

        std::stringstream idStream(id);
        int ID;
        if (!(idStream >> ID))
        {
            continue;
        }
        if (!salaryField.empty() && (salaryField[0] == 'R'))
        {
            salaryField = salaryField.substr(1);
        }
        std::stringstream salaryStream(salaryField);
        double salary;
        if (!(salaryStream >> salary))
        {
            continue;
        }
        Worker *worker = new Worker(name, salary);

        factory += worker;
        delete worker;
    }

    return is;
}

Factory &Factory::operator|(string filename)
{
    std::ifstream inputfile(filename.c_str());
    if (!inputfile.is_open())
    {
        return *this;
    }

    inputfile >> *this;
    inputfile.close();
    return *this;
}

int Factory::operator[](const Worker &worker) const
{

    /*if (this->workers == NULL || this->numWorkers == 0)
    {
        return -1;
    }*/

    for (int i = 0; i < this->numWorkers; i++)
    {
        if (workers[i] != NULL)
        {
            if (*this->workers[i] == worker)
            {
                return i;
            }
        }
    }

    return -1;
}
Worker *Factory::operator[](int index) const
{

    if (index >= 0 && index < numWorkers)
    {
        return workers[index];
    }
    return NULL;
}

void Factory::operator*=(const Factory &other)
{

    for (int i = 0; i < other.numWorkers; i++)
    {

        if (other.workers[i] != NULL)
        {

            *this += other.workers[i];
        }
    }
}

Factory *Factory::operator*(const Factory &other) const
{
    Factory *fact = new Factory();
    for (int i = 0; i < this->numWorkers; i++)
    {
        if (workers[i] != NULL)
        {

            *fact += workers[i];
        }
    }

    for (int i = 0; i < other.numWorkers; i++)
    {
        if (other.workers[i] != NULL)
        {
            *fact += other.workers[i];
        }
    }
    return fact;
}

Factory &Factory::operator+=(Worker *worker)
{

    if (worker == NULL)
    {
        return *this;
    }
    int id = (*this)[*worker];
    if (id != -1)
    {
        return *this;
    }
    Worker **op = new Worker *[numWorkers + 1];
    for (int i = 0; i < numWorkers; i++)
    {
        op[i] = workers[i];
    }
    op[numWorkers] = new Worker(*worker);

    delete[] workers;
    workers = op;
    numWorkers++;

    return *this;
}

Factory &Factory::operator+=(Worker &worker)
{

    int id = (*this)[worker];
    if (id != -1)
    {
        return *this;
    }

    Worker **op = new Worker *[numWorkers + 1];
    for (int i = 0; i < numWorkers; i++)
    {
        op[i] = workers[i];
    }
    op[numWorkers] = &worker;
    delete[] workers;
    workers = op;
    numWorkers++;

    return *this;
}
Factory &Factory::operator-=(Worker *worker)
{
    if (worker == NULL)
    {
        return *this;
    }
    int index = (*this)[*worker];
    if (index == -1)
    {
        return *this;
    }

    if (numWorkers == 1)
    {
        delete[] workers;
        workers = NULL;
        numWorkers = 0;
        return *this;
    }
    Worker **op = new Worker *[numWorkers - 1];
    int k = 0;
    for (int i = 0; i < numWorkers; i++)
    {
        if (i != index)
        {
            op[k] = workers[i];
            k++;
        }
    }

    delete[] workers;
    workers = op;
    --numWorkers;

    return *this;
}
bool Factory::operator==(const Factory &other) const
{

    double result = 0.0;
    for (int i = 0; i < numWorkers; i++)
    {
        if (workers[i] != NULL)
        {
            result += (*workers[i])();
        }
    }
    double other1 = 0.0;
    for (int i = 0; i < other.numWorkers; i++)
    {
        if (other.workers[i] != NULL)
        {
            other1 += (*other.workers[i])();
        }
    }
    return (result == other1);
}

bool Factory::operator!=(const Factory &other) const
{
    return !(*this == other);
}
const Factory &Factory::operator>(const Factory &other) const
{

    double result = 0.0;
    for (int i = 0; i < numWorkers; i++)
    {
        if (workers[i] != NULL)
        {
            result += (*workers[i])();
        }
    }
    double other1 = 0.0;
    for (int i = 0; i < other.numWorkers; i++)
    {
        if (other.workers[i] != NULL)
        {
            other1 += (*other.workers[i])();
        }
    }

    if (result == other1)
    {
        Factory *def = new Factory();
        return *def;
    }
    if (result > other1)
    {
        return *this;
    }
    return other;
}
const Factory &Factory::operator<(const Factory &other) const
{
    double result = 0.0;
    for (int i = 0; i < numWorkers; i++)
    {
        if (workers[i] != NULL)
        {
            result += (*workers[i])();
        }
    }
    double other1 = 0.0;
    for (int i = 0; i < other.numWorkers; i++)
    {
        if (other.workers[i] != NULL)
        {
            other1 += (*other.workers[i])();
        }
    }

    if (result == other1)
    {
        return other;
    }
    if (result < other1)
    {
        return *this;
    }
    return *this;
}
const Factory &Factory::operator>=(const Factory &other) const
{

    double result = 0.0;
    for (int i = 0; i < numWorkers; i++)
    {
        if (workers[i] != NULL)
        {
            result += (*workers[i])();
        }
    }
    double other1 = 0.0;
    for (int i = 0; i < other.numWorkers; i++)
    {
        if (other.workers[i] != NULL)
        {
            other1 += (*other.workers[i])();
        }
    }

    if (result == other1)
    {
        return other;
    }
    if (result >= other1)
    {
        return *this;
    }
    return *this;
}
const Factory &Factory::operator<=(const Factory &other) const
{
    double result = 0.0;
    for (int i = 0; i < numWorkers; i++)
    {
        if (workers[i] != NULL)
        {
            result += (*workers[i])();
        }
    }
    double other1 = 0.0;
    for (int i = 0; i < other.numWorkers; i++)
    {
        if (other.workers[i] != NULL)
        {
            other1 += (*other.workers[i])();
        }
    }

    if (result == other1)
    {
        return other;
    }
    if (result <= other1)
    {
        return *this;
    }
    return *this;
}
ostream &operator<<(ostream &os, const Factory &factory)
{
    if (factory.numWorkers == 0)
    {
        os << "Empty factory";
    }
    else
    {
        for (int i = 0; i < factory.numWorkers; i++)
        {
            if (factory.workers[i] != NULL)
            {
                os << *(factory.workers[i]) << '\n';
            }
        }
    }
    return os;
}

#include "Factory.h"
#include "Worker.h"
using namespace std;

Factory::Factory()
{
    numWorkers = 0;
    workers = NULL;
    workers = new Worker *[0];
}
Factory::~Factory()
{
    if (workers != NULL)
    {
        for (int i = 0; i < numWorkers; i++)
        {
            delete workers[i];
        }
        delete[] workers;
        workers = NULL;
    }
}

Factory &Factory::operator=(const Factory &other)
{
    if (this == &other)
    {
        return *this;
    }
    if (workers != NULL)
    {
        for (int i = 0; i < numWorkers; i++)
        {
            delete workers[i];
        }
        delete[] workers;
    }

    workers = new Worker *[numWorkers];
    for (int i = 0; i < numWorkers; i++)
    {
        workers[i] = new Worker(*other.workers[i]);
    }
    return *this;
}

Factory &Factory::operator|(string filename)
{
    std::ifstream inputfile(filename.c_str());
    if (!inputfile.is_open())
    {
        std::cout << "File doesn't exist. " << std ::endl;
        return *this;
    }
    std::string input;

    while (getline(inputfile, input))
    {
        std::stringstream ss(input);
        std::string name;
        double salary;
        int ID;
        if (ss >> ID >> name >> salary)
        {
            Worker *file = new Worker(name, salary);
            *this += file;
        }
    }
    return *this;
}

int Factory::operator[](const Worker &worker) const
{

    /*if (this->workers == NULL || this->numWorkers == 0)
    {
        return -1;
    }*/
    for (int i = 0; i < this->numWorkers; i++)
    {
        if (*workers[i] == worker)
        {
            return i;
        }
    }
    return -1;
}
Worker *Factory::operator[](int index) const
{
    if (index < 0 || index >= numWorkers)
    {
        return NULL;
    }
    return workers[index];
}

void Factory::operator*=(const Factory &other)
{

    for (int i = 0; i < other.numWorkers; i++)
    {
        Worker *file = other.operator[](i);

        if (file != NULL)
        {

            this->operator+=(file);
        }
    }
}

Factory *Factory::operator*(const Factory &other) const
{
    Factory *fact = new Factory();
    for (int i = 0; i < this->numWorkers; i++)
    {
        Worker *file = new Worker(*this->workers[i]);
        *fact += file;
    }

    for (int i = 0; i < other.numWorkers; i++)
    {
        Worker *file = new Worker(*other.workers[i]);
        *fact += file;
    }
    return fact;
}

Factory &Factory::operator+=(Worker *worker)
{

    if (worker == NULL)
    {
        return *this;
    }
    int id = (*this)[*worker];
    if (id != -1)
    {
        return *this;
    }
    Worker **op = new Worker *[numWorkers + 1];
    for (int i = 0; i < numWorkers; i++)
    {
        op[i] = workers[i];
    }
    op[numWorkers] = new Worker(*worker);

    delete[] workers;
    workers = op;
    ++numWorkers;

    return *this;
}

Factory &Factory::operator+=(Worker &worker)
{

    int id = (*this)[worker];
    if (id != -1)
    {
        return *this;
    }

    Worker **op = new Worker *[numWorkers + 1];
    for (int i = 0; i < numWorkers; i++)
    {
        op[i] = workers[i];
    }
    op[numWorkers] = &worker;
    delete[] workers;
    workers = op;
    ++numWorkers;

    return *this;
}
Factory &Factory::operator-=(Worker *worker)
{
    if (worker == NULL)
    {
        return *this;
    }
    int index = (*this)[*worker];
    if (index == -1)
    {
        return *this;
    }
    delete workers[index];
    Worker **op = new Worker *[numWorkers - 1];
    int k = 0;
    for (int i = 0; i < numWorkers; i++)
    {
        if (i != index)
        {
            op[k++] = workers[i];
        }
    }
    delete[] workers;
    workers = op;
    --numWorkers;

    return *this;
}
bool Factory::operator==(const Factory &other) const
{

    double result = 0.0;
    for (int i = 0; i < numWorkers; i++)
    {
        if (workers[i] != NULL)
        {
            result += (*workers[i])();
        }
    }
    double other1 = 0.0;
    for (int i = 0; i < other.numWorkers; i++)
    {
        if (other.workers[i] != NULL)
        {
            other1 += (*other.workers[i])();
        }
    }
    return (result == other1);
}

bool Factory::operator!=(const Factory &other) const
{
    return !(*this == other);
}
const Factory &Factory::operator>(const Factory &other) const
{

    double result = 0.0;
    for (int i = 0; i < numWorkers; i++)
    {
        if (workers[i] != NULL)
        {
            result += (*workers[i])();
        }
    }
    double other1 = 0.0;
    for (int i = 0; i < other.numWorkers; i++)
    {
        if (other.workers[i] != NULL)
        {
            other1 += (*other.workers[i])();
        }
    }

    if (result == other1)
    {
        return other;
    }
    if (result > other1)
    {
        return *this;
    }
    return *this;
}
const Factory &Factory::operator<(const Factory &other) const
{
    double result = 0.0;
    for (int i = 0; i < numWorkers; i++)
    {
        if (workers[i] != NULL)
        {
            result += (*workers[i])();
        }
    }
    double other1 = 0.0;
    for (int i = 0; i < other.numWorkers; i++)
    {
        if (other.workers[i] != NULL)
        {
            other1 += (*other.workers[i])();
        }
    }

    if (result == other1)
    {
        return other;
    }
    if (result < other1)
    {
        return *this;
    }
    return *this;
}
const Factory &Factory::operator>=(const Factory &other) const
{

    double result = 0.0;
    for (int i = 0; i < numWorkers; i++)
    {
        if (workers[i] != NULL)
        {
            result += (*workers[i])();
        }
    }
    double other1 = 0.0;
    for (int i = 0; i < other.numWorkers; i++)
    {
        if (other.workers[i] != NULL)
        {
            other1 += (*other.workers[i])();
        }
    }

    if (result == other1)
    {
        return other;
    }
    if (result >= other1)
    {
        return *this;
    }
    return *this;
}
const Factory &Factory::operator<=(const Factory &other) const
{
    double result = 0.0;
    for (int i = 0; i < numWorkers; i++)
    {
        if (workers[i] != NULL)
        {
            result += (*workers[i])();
        }
    }
    double other1 = 0.0;
    for (int i = 0; i < other.numWorkers; i++)
    {
        if (other.workers[i] != NULL)
        {
            other1 += (*other.workers[i])();
        }
    }

    if (result == other1)
    {
        return other;
    }
    if (result <= other1)
    {
        return *this;
    }
    return *this;
}
ostream &operator<<(ostream &os, const Factory &factory)
{
    if (factory.numWorkers == 0)
    {
        os << "Empty factory";
    }
    else
    {
        for (int i = 0; i < factory.numWorkers; i++)
        {
            if (factory.workers[i] != NULL)
            {
                os << *(factory.workers[i]) << '\n';
            }
        }
    }
    return os;
}
istream &operator>>(istream &is, Factory &factory)
{

    string input;
    while (std::getline(is, input))
    {
        /*if (input == "Empty factory")
        {
            continue;
        }*/
        std::string name;
        double salary;
        int ID;
        std::stringstream ss(input);
        if (ss >> ID >> name >> salary)
        {
            Worker *op = new Worker(name, salary);
            factory += op;
        }
    }
    return is;
}